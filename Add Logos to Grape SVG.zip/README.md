
  # Add Logos to Grape SVG

  This is a code bundle for Add Logos to Grape SVG. The original project is available at https://www.figma.com/design/fRa1ThhGGGkOtO4hZhJQ2e/Add-Logos-to-Grape-SVG.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  